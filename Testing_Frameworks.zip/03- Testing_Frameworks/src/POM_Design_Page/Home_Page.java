package POM_Design_Page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Home_Page {
WebDriver driver;


	public Home_Page(WebDriver driver) {
		
		this.driver=driver;
	
}


	public WebElement SignInBtn ()
	{
		return driver.findElement(By.id("gb_70"));
		
		
	}
}
